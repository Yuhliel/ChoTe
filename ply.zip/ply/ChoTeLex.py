import sys
import ply.lex as lex


#Lista con los tokens de las palabras reservadas del compilador.
reserved = {
	'begin'	:	'BEGIN'	,
	'main'	:	'MAIN'	,
	'return':	'RETURN',
	'end'	:	'END'	
	}

#Lista con todos los tokens de palabras reservadas.	
reservedaux {
	'begin'		:	'BEGIN'		,
	'main'		:	'MAIN'		,
	'return'	:	'RETURN'	,
	'end'		:	'END'		,
	'void'		:	'VOID'		,
	'boolean'	:	'BOOLEAN'	,
	'int'		:	'INT'		,
	'double'	:	'DOUBLE'	,
	'char'		:	'CHAR'		,
	'String'	:	'STRING'	,
	'if'		:	'IF'		,
	'else'		:	'ELSE'		,
	'for'		:	'FOR'		,
	'while'		:	'WHILE'		,	
	'do'		:	'DO'		,
	'read'		:	'READ'		,	
	'print'		:	'PRINT'			
}
#Lista con los tokens de los operadores del compilador.
operator = {
	'assign'		,	#'='
	'and'			,	#'&&'
	'or'			,	#'||'
	'negation'		,	#'!'
	'greater_than' 	,	#'>'
	'less_than'		,	#'<'
	'different'		,	#'!='
	'great_equal'	,	#'>='
	'less_equal'	,	#'<='	
	'equals'		,	#'=='
	'plus'			,	#'+'
	'minus'			,	#'-'
	'times'			,	#'*'
	'divide'		,	#'/'
	}

#Lista con los tokens de los tipos de variables del compilador.
type = {
	'void'		:	'VOID'		,
	'boolean'	:	'BOOLEAN'	,
	'int'		:	'INT'		,
	'double'	:	'DOUBLE'	,
	'char'		:	'CHAR'		,
	'String'	:	'STRING'	
	}

#Lista con los tokens de las condicionales del compilador.
condition = {
	'if'	:	'IF'	,
	'else'	:	'ELSE'
	}

#Lista con los tokens de los ciclos del compilador.
loop = {
	'for'	:	'FOR'	,
	'while'	:	'WHILE'	,
	'do'	:	'DO'
	}

#Lista con los tokens de ID, Constantes, Parentesis, Corchetes, etc.
other = {
	'ID'								,	#IDENTIFIACADOR
	'read'			:	'READ'			,	#FUNCION READ
	'print'			:	'PRINT'			,	#FUNCION PRINT
	'open_brace'						,	# "{"
	'open_paren'						,	# "("
	'open_bracket'						,	# "["
	'close_brace'						,	# "}"
	'close_paren'						,	# ")"
	'close_bracket'						,	# "]"	
	'semi_colon'						,	# ";"
	'comma'								,	# ","
	'cint'								,	# CONSTANTE INT		
	'cdouble'							,	# CONSTANTE DOUBLE	
	'cbool'								,	# CONSTANTE BOOLEAN
	'cstring'								# CONSTANTE STRING
	}

#####################################################################################

tokens = list(reserved.values()) + list(operator.values()) + list(type.values()) + 
			list(condition.values()) + list(loop.values()) + list(other.values())
			
#Expresiones Regulaes para definir los tokens
t_open_brace	=	r'\{'
t_open_paren	=	r'\('
t_open_bracket	= 	r'\['
t_close_brace	=	r'\}'
t_close_paren	=	r'\)'
t_close_bracket	=	r'\]'
t_semi_colon	=	r'\;'
t_comma			=	r'\,'
t_cstring		=	r'[a-zA-Z_][a-zA-Z0-9_]*'
t_assign		=	r'\='
t_and			=	r'\&\&'
t_or			=	r'\|\|'
t_negation		=	r'\!'
t_greater_than	=	r'\>'
t_less_than		=	r'\<'
t_different		=	r'\!\='
t_great_equal	=	r'\>\='
t_less_equal	=	r'\<\='
t_equals		=	r'\=\='
t_plus			=	r'\+'
t_minus			=	r'\-'
t_times			=	r'\*'
t_divide		=	r'\/'
t_ignore 		= 	" \t"

def t_ID(t):	
	r'[a-zA-Z_][a-zA-Z0-9_]*'
	t.type = reservedaux.get(t.value, 'ID')
	return t
	
def t_cint(t):
	r'\d+'
	t.value = int(t.value)
	except ValueError:													#Ruben Valdez
		print("El numero que deseas almacenar es MUY grande. D= ") 
		t.value = 0
	return t
	
def t_cdouble(t):
	r'[0-9]+\.[0-9]
	t.value = float(t.value)
	except ValueError:													#Ruben Valdez
		print("El numero que deseas almacenar es MUY grande. D= ") 
		t.value = 0.00
	return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += t.value.count("\n")
    
def t_error(t):
	print("Token Invalido >=( '%s'" % t.value[0])						#Ruben Valdez
    t.lexer.skip(1)    

lexer = lex.lex()